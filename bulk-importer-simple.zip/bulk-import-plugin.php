<?php
/*
Plugin Name: Simple HTML Importer
Description: Basic HTML page importer
Version: 1.0
*/

// Add admin menu
add_action('admin_menu', 'bulk_importer_menu');

function bulk_importer_menu() {
    add_menu_page(
        'HTML Importer',
        'HTML Importer',
        'manage_options',
        'html-importer',
        'importer_page'
    );
}

// Register plugin settings
add_action('admin_init', 'bulk_importer_settings');

function bulk_importer_settings() {
    register_setting('html_importer_group', 'html_importer_header_id');
    register_setting('html_importer_group', 'html_importer_footer_id');
    
    // Add settings section
    add_settings_section(
        'html_importer_section',
        'Template Settings',
        'html_importer_section_callback',
        'html_importer_group'
    );
    
    // Add settings fields
    add_settings_field(
        'html_importer_header_id',
        'Header Template ID',
        'html_importer_header_callback',
        'html_importer_group',
        'html_importer_section'
    );
    
    add_settings_field(
        'html_importer_footer_id',
        'Footer Template ID',
        'html_importer_footer_callback',
        'html_importer_group',
        'html_importer_section'
    );
}

function html_importer_section_callback() {
    echo '<p>Enter your Elementor template IDs below. You can find these by going to Templates in Elementor.</p>';
}

function html_importer_header_callback() {
    $header_id = get_option('html_importer_header_id');
    echo '<input type="text" name="html_importer_header_id" value="' . esc_attr($header_id) . '" class="regular-text">';
    if ($header_id) {
        echo '<p class="description">Current header template ID: ' . esc_html($header_id) . '</p>';
    }
}

function html_importer_footer_callback() {
    $footer_id = get_option('html_importer_footer_id');
    echo '<input type="text" name="html_importer_footer_id" value="' . esc_attr($footer_id) . '" class="regular-text">';
    if ($footer_id) {
        echo '<p class="description">Current footer template ID: ' . esc_html($footer_id) . '</p>';
    }
}

function importer_page() {
    if (!current_user_can('manage_options')) {
        wp_die('You do not have sufficient permissions to access this page.');
    }
    
    // Check if settings were updated
    if (isset($_GET['settings-updated'])) {
        add_settings_error(
            'html_importer_messages',
            'html_importer_message',
            'Settings Saved',
            'updated'
        );
    }
    
    ?>
    <div class="wrap">
        <h1>HTML Importer</h1>
        
        <?php
        // Show error/update messages
        settings_errors('html_importer_messages');
        ?>
        
        <!-- Settings Section -->
        <div class="card">
            <h2>Template Settings</h2>
            <form method="post" action="options.php">
                <?php
                settings_fields('html_importer_group');
                do_settings_sections('html_importer_group');
                submit_button('Save Settings');
                
                // Display current values
                $header_id = get_option('html_importer_header_id');
                $footer_id = get_option('html_importer_footer_id');
                if ($header_id || $footer_id) {
                    echo '<hr>';
                    echo '<h3>Current Settings</h3>';
                    echo '<ul>';
                    if ($header_id) {
                        echo '<li><strong>Header Template ID:</strong> ' . esc_html($header_id) . '</li>';
                    }
                    if ($footer_id) {
                        echo '<li><strong>Footer Template ID:</strong> ' . esc_html($footer_id) . '</li>';
                    }
                    echo '</ul>';
                }
                ?>
            </form>
        </div>

        <!-- Import Section -->
        <h2>Import Pages</h2>
        <form method="post" action="">
            <?php wp_nonce_field('html_import_action', 'html_import_nonce'); ?>
            <table class="form-table">
                <tr>
                    <th scope="row">Website URL</th>
                    <td>
                        <input type="url" name="website_url" class="regular-text" 
                               value="https://historicaviationmilitary.com" required>
                    </td>
                </tr>
            </table>
            <p class="submit">
                <input type="submit" name="scan_website" class="button button-primary" value="Scan Website">
            </p>
        </form>

        <?php
        // Handle website scanning
        if (isset($_POST['scan_website']) && check_admin_referer('html_import_action', 'html_import_nonce')) {
            $url = esc_url_raw($_POST['website_url']);
            
            try {
                $response = wp_remote_get($url);
                if (is_wp_error($response)) {
                    throw new Exception('Failed to connect to website');
                }

                $html = wp_remote_retrieve_body($response);
                $dom = new DOMDocument();
                @$dom->loadHTML($html, LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD);
                $xpath = new DOMXPath($dom);

                // Find all links
                $links = $xpath->query('//a[@href]');
                $found_pages = array();

                foreach ($links as $link) {
                    $href = $link->getAttribute('href');
                    if (strpos($href, '.html') !== false) {
                        $found_pages[] = array(
                            'url' => $href,
                            'title' => $link->textContent
                        );
                    }
                }

                if (!empty($found_pages)) {
                    echo '<h3>Found Pages</h3>';
                    echo '<form method="post">';
                    wp_nonce_field('import_pages_action', 'import_pages_nonce');
                    echo '<table class="widefat">';
                    echo '<thead><tr><th>Select</th><th>URL</th><th>Title</th></tr></thead>';
                    foreach ($found_pages as $page) {
                        echo '<tr>';
                        echo '<td><input type="checkbox" name="pages[]" value="' . esc_attr($page['url']) . '"></td>';
                        echo '<td>' . esc_html($page['url']) . '</td>';
                        echo '<td>' . esc_html($page['title']) . '</td>';
                        echo '</tr>';
                    }
                    echo '</table>';
                    echo '<p class="submit">';
                    echo '<input type="submit" name="import_pages" class="button button-primary" value="Import Selected Pages">';
                    echo '</p>';
                    echo '</form>';
                } else {
                    echo '<div class="notice notice-warning"><p>No HTML pages found.</p></div>';
                }
            } catch (Exception $e) {
                echo '<div class="notice notice-error"><p>Error: ' . esc_html($e->getMessage()) . '</p></div>';
            }
        }
        ?>
    </div>
    <?php
}
